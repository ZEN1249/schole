package com.example.freshtrack

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.freshtrack.databinding.ItemProductBinding

class ProductAdapter(private val onClick: (Long) -> Unit) :
    ListAdapter<Product, ProductAdapter.ProductHolder>(ProductDiff) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductHolder =
        ProductHolder(ItemProductBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ProductHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ProductHolder(private val binding: ItemProductBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(product: Product) {
            val context = binding.root.context
            val expiration = parseExpiration(product.expirationDate)
            binding.productName.text = product.name
            binding.productDate.text = context.getString(R.string.detail_date, expiration.displayDate(context))
            binding.expirationStatus.showExpirationStatus(expiration)
            binding.root.setOnClickListener { onClick(product.id) }
        }
    }

    private object ProductDiff : DiffUtil.ItemCallback<Product>() {
        override fun areItemsTheSame(oldItem: Product, newItem: Product): Boolean =
            oldItem.id == newItem.id

        override fun areContentsTheSame(oldItem: Product, newItem: Product): Boolean =
            oldItem == newItem
    }
}
