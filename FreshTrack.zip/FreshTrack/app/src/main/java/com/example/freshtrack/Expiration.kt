package com.example.freshtrack

import android.content.Context
import android.widget.TextView
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.time.temporal.ChronoUnit

private val displayFormat = DateTimeFormatter.ofPattern("dd.MM.uuuu")

fun parseExpiration(value: String?): LocalDate? = value?.let {
    try {
        LocalDate.parse(it)
    } catch (_: DateTimeParseException) {
        null
    }
}

fun LocalDate?.displayDate(context: Context): String =
    this?.format(displayFormat) ?: context.getString(R.string.unknown_expiration)

fun TextView.showExpirationStatus(expiration: LocalDate?) {
    val days = expiration?.let { ChronoUnit.DAYS.between(LocalDate.now(), it) }
    val (message, color) = when {
        days == null -> context.getString(R.string.unknown_expiration) to R.color.expiration_urgent
        days == 0L -> context.getString(R.string.expires_today) to R.color.expiration_urgent
        days == -1L -> context.getString(R.string.expired_one_day) to R.color.expiration_urgent
        days < 0 -> context.getString(R.string.expired_days, -days) to R.color.expiration_urgent
        days == 1L -> context.getString(R.string.expires_in_one_day) to R.color.expiration_soon
        days <= 3 -> context.getString(R.string.expires_in_days, days) to R.color.expiration_soon
        else -> context.getString(R.string.expires_in_days, days) to R.color.expiration_fresh
    }
    text = message
    setTextColor(ContextCompat.getColor(context, color))
}
