package com.example.freshtrack

import android.database.sqlite.SQLiteException
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.example.freshtrack.databinding.ActivityProductDetailsBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class ProductDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProductDetailsBinding
    private val dao by lazy { AppDatabase.get(this).productDao() }
    private val productId by lazy { intent.getLongExtra(EXTRA_PRODUCT_ID, 0L) }
    private var loadJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductDetailsBinding.inflate(layoutInflater)
        setScreenContent(binding.root)
        binding.toolbar.setTitle(R.string.product_details)
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            try {
                val product = if (productId > 0) dao.getById(productId) else null
                if (product == null) {
                    showMessage(R.string.missing_product)
                    finish()
                } else {
                    showProduct(product)
                }
            } catch (_: SQLiteException) {
                binding.productCard.isVisible = false
                showMessage(R.string.load_error)
            }
        }
    }

    private fun showProduct(product: Product) {
        val expiration = parseExpiration(product.expirationDate)
        binding.productName.text = product.name
        binding.category.text = getString(R.string.detail_category, product.category)
        binding.quantity.text = getString(R.string.detail_quantity, product.quantity)
        binding.date.text = getString(R.string.detail_date, expiration.displayDate(this))
        binding.storage.text = getString(R.string.detail_storage, product.storageLocation)
        binding.expirationStatus.showExpirationStatus(expiration)
        binding.editProduct.setOnClickListener {
            openProductScreen(ProductFormActivity::class.java, product.id)
        }
        binding.deleteProduct.setOnClickListener { confirmDelete(product) }
        binding.productCard.isVisible = true
    }

    private fun confirmDelete(product: Product) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.delete_title)
            .setMessage(getString(R.string.delete_message, product.name))
            .setNegativeButton(R.string.cancel, null)
            .setPositiveButton(R.string.delete) { _, _ -> deleteProduct(product.id) }
            .show()
    }

    private fun deleteProduct(id: Long) {
        binding.deleteProduct.isEnabled = false
        binding.editProduct.isEnabled = false
        lifecycleScope.launch {
            try {
                dao.deleteById(id)
                finish()
            } catch (_: SQLiteException) {
                showMessage(R.string.delete_error)
                binding.deleteProduct.isEnabled = true
                binding.editProduct.isEnabled = true
            }
        }
    }

    private fun showMessage(message: Int) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
