package com.example.freshtrack

import android.database.sqlite.SQLiteException
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.freshtrack.databinding.ActivityMainBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val dao by lazy { AppDatabase.get(this).productDao() }
    private val adapter = ProductAdapter { openProductScreen(ProductDetailsActivity::class.java, it) }
    private var loadJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setScreenContent(binding.root)

        binding.products.layoutManager = LinearLayoutManager(this)
        binding.products.adapter = adapter
        binding.addProduct.setOnClickListener { openProductScreen(ProductFormActivity::class.java) }
    }

    override fun onResume() {
        super.onResume()
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            try {
                val products = dao.getAll()
                adapter.submitList(products)
                binding.products.isVisible = products.isNotEmpty()
                binding.listMessage.setText(R.string.empty_products)
                binding.listMessage.isVisible = products.isEmpty()
            } catch (_: SQLiteException) {
                binding.products.isVisible = false
                binding.listMessage.setText(R.string.load_error)
                binding.listMessage.isVisible = true
            }
        }
    }
}
