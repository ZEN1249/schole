package com.example.freshtrack

import android.app.Activity
import android.app.ActivityOptions
import android.content.Intent
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding

const val EXTRA_PRODUCT_ID = "com.example.freshtrack.PRODUCT_ID"

fun AppCompatActivity.setScreenContent(root: View, includeKeyboard: Boolean = false) {
    enableEdgeToEdge()
    setContentView(root)
    ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
        val bars = insets.getInsets(
            WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
        )
        val keyboard = if (includeKeyboard) insets.getInsets(WindowInsetsCompat.Type.ime()).bottom else 0
        view.updatePadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, keyboard))
        insets
    }
}

fun Activity.openProductScreen(screen: Class<out Activity>, productId: Long? = null) {
    val intent = Intent(this, screen)
    if (productId != null) intent.putExtra(EXTRA_PRODUCT_ID, productId)
    val animation = ActivityOptions.makeCustomAnimation(
        this, android.R.anim.fade_in, android.R.anim.fade_out
    )
    startActivity(intent, animation.toBundle())
}
