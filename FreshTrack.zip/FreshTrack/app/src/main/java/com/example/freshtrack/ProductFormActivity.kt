package com.example.freshtrack

import android.app.DatePickerDialog
import android.database.sqlite.SQLiteException
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.freshtrack.ProductFormViewModel.SaveState
import com.example.freshtrack.databinding.ActivityProductFormBinding
import kotlinx.coroutines.launch
import java.time.LocalDate

class ProductFormActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProductFormBinding
    private val viewModel: ProductFormViewModel by viewModels()
    private val isEditing by lazy { intent.hasExtra(EXTRA_PRODUCT_ID) }
    private val productId by lazy { intent.getLongExtra(EXTRA_PRODUCT_ID, 0L) }
    private var expiration: LocalDate? = null
    private var formReady = false
    private var datePicker: DatePickerDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProductFormBinding.inflate(layoutInflater)
        setScreenContent(binding.root, includeKeyboard = true)
        binding.heading.setText(if (isEditing) R.string.edit_product else R.string.add_product)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.dateInput.setOnClickListener { pickDate() }
        binding.saveProduct.setOnClickListener { validateAndSave() }
        binding.nameInput.isSaveEnabled = false
        binding.quantityInput.isSaveEnabled = false
        binding.categoryInput.isSaveEnabled = false
        binding.storageInput.isSaveEnabled = false

        formReady = !isEditing || savedInstanceState?.getBoolean(STATE_READY) == true
        if (formReady && savedInstanceState != null) restoreDraft(savedInstanceState)
        renderDate()
        updateControls(viewModel.saveState.value)
        observeSave()

        if (!formReady && viewModel.saveState.value == SaveState.READY) loadForEditing()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(STATE_READY, formReady)
        outState.putString(STATE_NAME, binding.nameInput.text.toString())
        outState.putString(STATE_QUANTITY, binding.quantityInput.text.toString())
        outState.putInt(STATE_CATEGORY, binding.categoryInput.selectedItemPosition)
        outState.putInt(STATE_STORAGE, binding.storageInput.selectedItemPosition)
        outState.putString(STATE_DATE, expiration?.toString())
    }

    override fun onDestroy() {
        datePicker?.dismiss()
        super.onDestroy()
    }

    private fun restoreDraft(state: Bundle) {
        binding.nameInput.setText(state.getString(STATE_NAME))
        binding.quantityInput.setText(state.getString(STATE_QUANTITY))
        binding.categoryInput.setSelection(state.getInt(STATE_CATEGORY).coerceAtLeast(0))
        binding.storageInput.setSelection(state.getInt(STATE_STORAGE).coerceAtLeast(0))
        expiration = parseExpiration(state.getString(STATE_DATE))
    }

    private fun loadForEditing() {
        lifecycleScope.launch {
            try {
                val product = if (productId > 0) viewModel.loadProduct(productId) else null
                if (product == null) {
                    showMessage(R.string.missing_product)
                    finish()
                    return@launch
                }

                binding.nameInput.setText(product.name)
                binding.quantityInput.setText(product.quantity.toString())
                val categories = resources.getStringArray(R.array.product_categories)
                val locations = resources.getStringArray(R.array.storage_locations)
                binding.categoryInput.setSelection(categories.indexOf(product.category).coerceAtLeast(0))
                binding.storageInput.setSelection(locations.indexOf(product.storageLocation).coerceAtLeast(0))
                expiration = parseExpiration(product.expirationDate)
                renderDate()
                formReady = true
                updateControls(viewModel.saveState.value)
            } catch (_: SQLiteException) {
                showMessage(R.string.load_error)
                finish()
            }
        }
    }

    private fun observeSave() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.saveState.collect { state ->
                    updateControls(state)
                    when (state) {
                        SaveState.SAVED -> finish()
                        SaveState.MISSING -> {
                            showMessage(R.string.missing_product)
                            finish()
                        }
                        SaveState.ERROR -> {
                            showMessage(R.string.save_error)
                            viewModel.acknowledgeError()
                        }
                        SaveState.READY, SaveState.SAVING -> Unit
                    }
                }
            }
        }
    }

    private fun updateControls(state: SaveState) {
        val editable = formReady && state == SaveState.READY
        binding.nameInput.isEnabled = editable
        binding.quantityInput.isEnabled = editable
        binding.categoryInput.isEnabled = editable
        binding.storageInput.isEnabled = editable
        binding.dateInput.isEnabled = editable
        binding.saveProduct.isEnabled = editable
    }

    private fun pickDate() {
        val initial = expiration ?: LocalDate.now()
        datePicker = DatePickerDialog(this, { _, year, month, day ->
            expiration = LocalDate.of(year, month + 1, day)
            binding.dateError.isVisible = false
            renderDate()
        }, initial.year, initial.monthValue - 1, initial.dayOfMonth).apply { show() }
    }

    private fun renderDate() {
        binding.dateInput.text = expiration?.displayDate(this) ?: getString(R.string.pick_date)
    }

    private fun validateAndSave() {
        val name = binding.nameInput.text.toString().trim()
        val quantity = binding.quantityInput.text.toString().trim().toIntOrNull()
        val date = expiration
        val nameValid = name.isNotBlank()
        val quantityValid = quantity != null && quantity > 0
        binding.nameInputLayout.error = if (nameValid) null else getString(R.string.error_name)
        binding.quantityInputLayout.error = if (quantityValid) null else getString(R.string.error_quantity)
        binding.dateError.isVisible = date == null
        if (!nameValid || quantity == null || !quantityValid || date == null) return

        viewModel.saveProduct(
            Product(
                id = productId,
                name = name,
                category = binding.categoryInput.selectedItem.toString(),
                quantity = quantity,
                expirationDate = date.toString(),
                storageLocation = binding.storageInput.selectedItem.toString()
            )
        )
    }

    private fun showMessage(message: Int) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val STATE_READY = "formReady"
        const val STATE_NAME = "productName"
        const val STATE_QUANTITY = "productQuantity"
        const val STATE_CATEGORY = "productCategory"
        const val STATE_STORAGE = "productStorage"
        const val STATE_DATE = "productExpiration"
    }
}
