package com.example.freshtrack

import android.app.Application
import android.database.sqlite.SQLiteException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ProductFormViewModel(application: Application) : AndroidViewModel(application) {
    enum class SaveState { READY, SAVING, SAVED, MISSING, ERROR }

    private val dao = AppDatabase.get(application).productDao()
    private val mutableSaveState = MutableStateFlow(SaveState.READY)
    val saveState = mutableSaveState.asStateFlow()

    suspend fun loadProduct(id: Long): Product? = dao.getById(id)

    fun saveProduct(product: Product) {
        if (mutableSaveState.value != SaveState.READY) return
        mutableSaveState.value = SaveState.SAVING

        viewModelScope.launch {
            mutableSaveState.value = try {
                if (product.id == 0L) {
                    dao.insert(product)
                    SaveState.SAVED
                } else if (dao.update(product) > 0) {
                    SaveState.SAVED
                } else {
                    SaveState.MISSING
                }
            } catch (_: SQLiteException) {
                SaveState.ERROR
            }
        }
    }

    fun acknowledgeError() {
        if (mutableSaveState.value == SaveState.ERROR) {
            mutableSaveState.value = SaveState.READY
        }
    }
}
